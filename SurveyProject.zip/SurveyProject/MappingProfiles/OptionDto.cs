﻿namespace SurveyProject.MappingProfiles
{
    public class OptionDto
    {
        public int Id { get; set; }
        public string OptionText { get; set; }
    }
}
