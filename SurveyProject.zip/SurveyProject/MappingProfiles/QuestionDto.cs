﻿namespace SurveyProject.MappingProfiles
{
    public class QuestionDto
    {
        public string QuestionText { get; set; }
        public int QuestionTypeId { get; set; }
        public int SurveyId { get; set; }

    }
}
